(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [43695], {
        45555: function(n, t, s) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/assets/[chain]/[assetContractAddress]/[tokenId]", function() {
                return s(10720)
            }])
        },
        10720: function(n, t, s) {
            "use strict";
            s.r(t);
            var u = s(20924);
            t.default = u.r
        }
    },
    function(n) {
        n.O(0, [49774, 48891, 44833, 50114, 28263, 66391, 19969, 71736, 31523, 25459, 46951, 60354, 4459, 13056, 11424, 39653, 16466, 45890, 88515, 5001, 70343, 90416, 14516, 20924, 92888, 40179], (function() {
            return t = 45555, n(n.s = t);
            var t
        }));
        var t = n.O();
        _N_E = t
    }
]);
//# sourceMappingURL=[tokenId]-703b0a2729fcedd6.js.map